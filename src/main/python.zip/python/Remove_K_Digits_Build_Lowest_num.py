'''
https://leetcode.com/problems/remove-k-digits/

Given string num representing a non-negative integer num, and an integer k, return the smallest possible integer after removing k digits from num.

 

Example 1:

Input: num = "1432219", k = 3
Output: "1219"
Explanation: Remove the three digits 4, 3, and 2 to form the new number 1219 which is the smallest.
Example 2:

Input: num = "10200", k = 1
Output: "200"
Explanation: Remove the leading 1 and the number is 200. Note that the output must not contain leading zeroes.
Example 3:

Input: num = "10", k = 2
Output: "0"
Explanation: Remove all the digits from the number and it is left with nothing which is 0.
 

Constraints:

1 <= k <= num.length <= 105
num consists of only digits.
num does not have any leading zeros except for the zero itself.

'''

class Solution(object):
    def removeKdigits(self, nums, k):
        """
        :type num: str
        :type k: int
        :rtype: str
        """
        if len(nums)==k:
            return "0"
        stack=[]
        count=0
        stack.append(nums[0])
        for i in range(1,len(nums)):
            while(stack and stack[-1]>nums[i]):
                stack.pop()
                count+=1
                if count==k:
                    if stack:
                        print ("1")
                        return str(int("".join(stack)))+"".join(nums[i:])
                    else:
                        print ("2")
                        return str(int("".join(nums[i:])))
            stack.append(nums[i])
            print ("stack:"+str(stack))
        while (stack and count<k):
            print ("inside 2nd while:"+str(stack))
            stack.pop()
            count+=1
        print ("3")
        return str(int("".join(stack)))
    
print (Solution().removeKdigits("9932929",3))