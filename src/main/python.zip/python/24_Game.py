'''
679. 24 Game
Hard

1023

194

Add to List

Share
You are given an integer array cards of length 4. You have four cards, each containing a number in the range [1, 9]. You should arrange the numbers on these cards in a mathematical expression using the operators ['+', '-', '*', '/'] and the parentheses '(' and ')' to get the value 24.

You are restricted with the following rules:

The division operator '/' represents real division, not integer division.
For example, 4 / (1 - 2 / 3) = 4 / (1 / 3) = 12.
Every operation done is between two numbers. In particular, we cannot use '-' as a unary operator.
For example, if cards = [1, 1, 1, 1], the expression "-1 - 1 - 1 - 1" is not allowed.
You cannot concatenate numbers together
For example, if cards = [1, 2, 1, 2], the expression "12 + 12" is not valid.
Return true if you can get such expression that evaluates to 24, and false otherwise.

 

Example 1:

Input: cards = [4,1,8,7]
Output: true
Explanation: (8-4) * (7-1) = 24
Example 2:

Input: cards = [1,2,1,2]
Output: false
 

Constraints:

cards.length == 4
1 <= cards[i] <= 9
'''


ops = [lambda a,b: a+b, lambda a,b: a*b, lambda a,b: a-b, lambda a,b: b-a, lambda a,b: a/b, lambda a,b: b/a]

class Solution:
    def judgePoint24(self, cards) :
        def backtrack(n) :
            if n == 1:
                return abs(cards[0] - 24) < 0.01
            for i in range(n):
                a = cards[i]
                for j in range(i+1, n):
                    b = cards[j]
                    cards[j] = cards[n-1]
                    print ("a,b,card[j]:"+str(a),str(b),str(cards[j]))
                    for op in ops:
                        try:
                            print ((op(a,b)))
                            cards[i] = op(a,b)
                            if backtrack(n-1):
                                return True
                        except ZeroDivisionError:
                            pass
                    cards[j] = b
                cards[i] = a
            return False
        return backtrack(4)
    
cards = [4,1,8,7]   
print (Solution().judgePoint24(cards))
